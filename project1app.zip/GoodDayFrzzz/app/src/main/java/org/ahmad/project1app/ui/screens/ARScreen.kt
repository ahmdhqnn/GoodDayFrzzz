package org.ahmad.project1app.ui.screens

import android.Manifest
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.util.Log
import android.view.MotionEvent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import com.google.ar.core.AugmentedImage
import com.google.ar.core.AugmentedImageDatabase
import com.google.ar.core.Config
import com.google.ar.core.TrackingState
import io.github.sceneview.ar.ARScene
import io.github.sceneview.ar.node.AugmentedImageNode
import io.github.sceneview.ar.rememberARCameraNode
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Scale
import io.github.sceneview.node.CubeNode
import io.github.sceneview.node.Node
import io.github.sceneview.rememberCollisionSystem
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberMaterialLoader
import io.github.sceneview.rememberModelLoader
import io.github.sceneview.rememberNodes
import io.github.sceneview.rememberOnGestureListener
import io.github.sceneview.rememberView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.ahmad.project1app.R
import org.ahmad.project1app.navigation.Screen
import org.ahmad.project1app.ui.theme.Project1appTheme

@OptIn(ExperimentalMaterial3Api::class, ExperimentalPermissionsApi::class)
@Composable
fun ARScreen(navController: NavHostController) {
    val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)
    val lifecycleOwner = LocalLifecycleOwner.current
    var showPermissionDialog by remember { mutableStateOf(false) }
    var isTrackingImage by remember { mutableStateOf(false) }
    var detectedImageName by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (!cameraPermissionState.status.isGranted) {
                    cameraPermissionState.launchPermissionRequest()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(),
                title = {
                    Text(
                        text = stringResource(R.string.ar_title),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(0) { inclusive = true }
                            launchSingleTop = true
                        }
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        when {
            cameraPermissionState.status.isGranted -> {
                Box(modifier = Modifier.fillMaxSize()) {
                    ARCameraView(
                        modifier = Modifier.padding(innerPadding),
                        onImageDetectionStateChanged = { imageName, isTracking ->
                            isTrackingImage = isTracking
                            if (isTracking) {
                                detectedImageName = imageName
                            }
                        },
                        onError = { message ->
                            errorMessage = message
                        }
                    )

                    // Overlay UI showing tracking status
                    if (!isTrackingImage) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Arahkan kamera ke gambar target",
                                style = MaterialTheme.typography.bodyLarge,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            CircularProgressIndicator()
                        }
                    } else {
                        Text(
                            text = "Terdeteksi: $detectedImageName",
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 80.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Show error message if any
                    errorMessage?.let { error ->
                        Text(
                            text = error,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 16.dp, start = 16.dp, end = 16.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            cameraPermissionState.status.shouldShowRationale || showPermissionDialog -> {
                PermissionRationaleDialog(
                    onRequestPermission = { cameraPermissionState.launchPermissionRequest() },
                    onDismiss = { showPermissionDialog = false }
                )
            }
            else -> {
                Box(
                    modifier = Modifier
                        .padding(innerPadding)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(R.string.camera_permission_needed),
                        style = MaterialTheme.typography.headlineSmall,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = { showPermissionDialog = true },
                        modifier = Modifier.padding(top = 16.dp)
                    ) {
                        Text("Minta Izin Kamera")
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionRationaleDialog(
    onRequestPermission: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Izin Kamera Diperlukan") },
        text = { Text("Aplikasi membutuhkan izin kamera untuk menampilkan fitur AR") },
        confirmButton = {
            Button(onClick = onRequestPermission) {
                Text("Berikan Izin")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun ARCameraView(
    modifier: Modifier = Modifier,
    onImageDetectionStateChanged: (String, Boolean) -> Unit = { _, _ -> },
    onError: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine = engine)
    val materialLoader = rememberMaterialLoader(engine = engine)
    val cameraNode = rememberARCameraNode(engine = engine)
    val childNodes = rememberNodes()
    val view = rememberView(engine = engine)
    val collisionSystem = rememberCollisionSystem(view = view)
    val coroutineScope = rememberCoroutineScope()

    // Referensi gambar yang sedang dilacak
    var trackingImageName by remember { mutableStateOf("") }

    // Status pemuatan model
    var isModelLoaded by remember { mutableStateOf(false) }

    // Clean up resources when composable is disposed
    DisposableEffect(Unit) {
        onDispose {
            // Hapus semua node saat keluar
            childNodes.clear()
        }
    }

    ARScene(
        modifier = modifier.fillMaxSize(),
        engine = engine,
        view = view,
        cameraNode = cameraNode,
        childNodes = childNodes,
        modelLoader = modelLoader,
        materialLoader = materialLoader,
        collisionSystem = collisionSystem,
        planeRenderer = true,
        sessionConfiguration = { session, config ->
            config.apply {
                planeFindingMode = Config.PlaneFindingMode.HORIZONTAL
                lightEstimationMode = Config.LightEstimationMode.ENVIRONMENTAL_HDR
                updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                focusMode = Config.FocusMode.AUTO

                // Setup augmented image database
                try {
                    val augmentedImageDb = AugmentedImageDatabase(session)

                    // Load and prepare image target
                    val bitmap = BitmapFactory.decodeResource(
                        context.resources,
                        R.drawable.target_image
                    )

                    if (bitmap != null) {
                        // Tambahkan gambar dengan ukuran fisik 0.1 meter (10 cm) - lebih kecil agar lebih mudah dideteksi
                        val imageIndex = augmentedImageDb.addImage("target_image", bitmap, 0.1f)
                        if (imageIndex >= 0) {
                            Log.d("ARScreen", "Gambar berhasil ditambahkan ke database dengan indeks: $imageIndex")
                            augmentedImageDatabase = augmentedImageDb
                            isModelLoaded = true // Anggap model sudah siap
                        } else {
                            Log.e("ARScreen", "Gagal menambahkan gambar ke database")
                            onError("Gagal menambahkan gambar target ke database AR")
                        }
                    } else {
                        Log.e("ARScreen", "Tidak dapat memuat bitmap gambar")
                        onError("Tidak dapat memuat gambar target - pastikan file target_image.jpeg ada di folder drawable")
                    }
                } catch (e: Exception) {
                    Log.e("ARScreen", "Error saat menyiapkan database gambar augmented", e)
                    onError("Error saat menyiapkan database gambar: ${e.localizedMessage}")
                }
            }
        },
        onSessionUpdated = { _, updatedFrame ->
            // Process augmented images
            val updatedAugmentedImages = updatedFrame.getUpdatedTrackables(AugmentedImage::class.java)

            for (augmentedImage in updatedAugmentedImages) {
                when (augmentedImage.trackingState) {
                    TrackingState.TRACKING -> {
                        val imageName = augmentedImage.name

                        if (trackingImageName != imageName) {
                            trackingImageName = imageName
                            onImageDetectionStateChanged(imageName, true)

                            Log.d("ARScreen", "Gambar terdeteksi: $imageName")

                            // Buat simpel cube di atas gambar sebagai pengganti model 3D
                            try {
                                // Buat node untuk gambar yang terdeteksi
                                val anchorNode = AugmentedImageNode(
                                    engine = engine,
                                    augmentedImage = augmentedImage
                                )

                                // Tambahkan kubus sebagai visualisasi sederhana
                                val cubeNode = CubeNode(
                                    engine = engine,
                                    size = Scale(0.05f, 0.05f, 0.05f),
                                    center = Position(0f, 0.025f, 0f)
                                )

                                anchorNode.addChildNode(cubeNode)
                                childNodes.add(anchorNode)

                                Log.d("ARScreen", "Kubus 3D berhasil ditampilkan di atas gambar")
                            } catch (e: Exception) {
                                Log.e("ARScreen", "Error saat menampilkan objek 3D", e)
                                onError("Error saat menampilkan objek 3D: ${e.localizedMessage}")
                            }
                        }
                    }
                    TrackingState.STOPPED -> {
                        // Jika gambar yang sedang dilacak berhenti dilacak
                        if (trackingImageName == augmentedImage.name) {
                            // Reset status tracking
                            trackingImageName = ""
                            onImageDetectionStateChanged("", false)

                            // Hapus semua node anak (termasuk model)
                            childNodes.removeIf { it is AugmentedImageNode }

                            Log.d("ARScreen", "Pelacakan gambar berhenti: ${augmentedImage.name}")
                        }
                    }
                    else -> {}
                }
            }
        },
        onGestureListener = rememberOnGestureListener(
            onSingleTapConfirmed = { _: MotionEvent, node: Node? ->
                // Opsional: tangani tap pada model
                if (node is CubeNode) {
                    Log.d("ARScreen", "Kubus di-tap")
                    // Rotate the cube when tapped
                    coroutineScope.launch {
                        val originalRotation = node.rotation
                        for (i in 0..360 step 10) {
                            delay(16) // ~60fps
                            node.rotation = Rotation(
                                originalRotation.x,
                                originalRotation.y + i,
                                originalRotation.z
                            )
                        }
                        node.rotation = originalRotation
                    }
                }
            }
        )
    )
}

@Preview(showBackground = true)
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES, showBackground = true)
@Composable
fun ARPreview() {
    Project1appTheme {
        ARScreen(rememberNavController())
    }
}